#!/usr/bin/osascript -l JavaScript
{prompt:target}

ObjC.import("AppKit");
ObjC.import("ApplicationServices");

function checkAX(status, operation) {
    if (status !== 0) throw new Error(operation + " failed (Accessibility error " + status + ").");
}
function readAttribute(editor, name) {
    const value = Ref();
    checkAX($.AXUIElementCopyAttributeValue(editor, $(name), value), "Read " + name);
    return ObjC.castRefToObject(value[0]);
}
function isWritable(editor, name) {
    const writable = Ref();
    const status = $.AXUIElementIsAttributeSettable(editor, $(name), writable);
    if (status === Number($.kAXErrorAttributeUnsupported)) return false;
    checkAX(status, "Check " + name);
    return Boolean(writable[0]);
}
function writeAttribute(editor, name, value) {
    checkAX($.AXUIElementSetAttributeValue(editor, $(name), value), "Set " + name);
}
function now() { return Number($.NSProcessInfo.processInfo.systemUptime); }
function pause() { $.NSThread.sleepForTimeInterval(0.01); }
function waitForEditor(check) {
    const deadline = now() + 2;
    while (!check()) {
        if (now() >= deadline) throw new Error("The editor did not confirm the requested cursor position within two seconds.");
        pause();
    }
}
function stableSnapshot(read) {
    const deadline = now() + 3;
    let previous = null;
    let since = now();
    while (now() < deadline) {
        const snapshot = read();
        const key = JSON.stringify([snapshot.text, snapshot.prefix, snapshot.location, snapshot.length, snapshot.collapsed]);
        if (key !== previous) { previous = key; since = now(); }
        else if (now() - since >= 0.04) return snapshot;
        pause();
    }
    throw new Error("The editor's text or cursor is still changing. Finish typing and run the action again.");
}
function readParameter(editor, name, parameter) {
    const value = Ref();
    checkAX($.AXUIElementCopyParameterizedAttributeValue(editor, $(name), parameter, value), "Read " + name);
    return ObjC.castRefToObject(value[0]);
}
function supportsTextMarkers(editor) {
    const available = Ref();
    const status = $.AXUIElementCopyParameterizedAttributeNames(editor, available);
    if (status === Number($.kAXErrorNotImplemented)) return false;
    checkAX(status, "Read editor accessibility capabilities");
    const names = ObjC.castRefToObject(available[0]);
    return ["AXTextMarkerRangeForUIElement", "AXStringForTextMarkerRange", "AXPreviousTextMarkerForTextMarker", "AXNextTextMarkerForTextMarker"].every(name => names.containsObject(name)) && isWritable(editor, "AXSelectedTextMarkerRange");
}
function textBetween(editor, start, end) {
    return ObjC.unwrap(readParameter(editor, "AXStringForTextMarkerRange", $.AXTextMarkerRangeCreate(null, start, end)));
}
function readMarkerCursor(editor) {
    const fullRange = readParameter(editor, "AXTextMarkerRangeForUIElement", editor);
    const start = $.AXTextMarkerRangeCopyStartMarker(fullRange);
    const end = $.AXTextMarkerRangeCopyEndMarker(fullRange);
    const selection = readAttribute(editor, "AXSelectedTextMarkerRange");
    const caret = $.AXTextMarkerRangeCopyEndMarker(selection);
    return { start: start, caret: caret, prefix: textBetween(editor, start, caret), text: textBetween(editor, start, end), collapsed: Boolean($.CFEqual($.AXTextMarkerRangeCopyStartMarker(selection), caret)) };
}
function markerAt(editor, cursor, position) {
    let marker = cursor.caret;
    let prefix = cursor.prefix;
    while (prefix.length > position) {
        const next = readParameter(editor, "AXPreviousTextMarkerForTextMarker", marker);
        if ($.CFEqual(next, marker)) throw new Error("The editor could not reach the requested position.");
        const nextPrefix = textBetween(editor, cursor.start, next);
        if (nextPrefix.length >= prefix.length) throw new Error("The editor's text markers did not move backwards.");
        marker = next;
        prefix = nextPrefix;
    }
    if (prefix !== cursor.text.slice(0, position)) throw new Error("Could not match the requested position in the editor.");
    return marker;
}
function lastMatch(text, searchText) {
    if (searchText === "") return null;
    const result = $(text).rangeOfStringOptions(searchText, $.NSBackwardsSearch | $.NSCaseInsensitiveSearch);
    return Number(result.length) === 0 ? null : Number(result.location);
}
function requestNewSearchText(path) {
    const request = JSON.stringify({ prompt: 1, message: "Text not found before the cursor. Enter another search text." });
    const error = Ref();
    if (!$(request).writeToFileAtomicallyEncodingError(path, true, $.NSUTF8StringEncoding, error)) throw new Error("Could not request another search text.");
}
function moveUsingMarkers(editor, searchText, retryPath) {
    ObjC.bindFunction("AXTextMarkerRangeCreate", ["id", ["id", "id", "id"]]);
    ObjC.bindFunction("AXTextMarkerRangeCopyStartMarker", ["id", ["id"]]);
    ObjC.bindFunction("AXTextMarkerRangeCopyEndMarker", ["id", ["id"]]);
    const cursor = stableSnapshot(() => readMarkerCursor(editor));
    if (!cursor.text.startsWith(cursor.prefix)) throw new Error("Could not locate the cursor within the editor's text markers.");
    const match = lastMatch(cursor.prefix, searchText);
    if (match === null) { requestNewSearchText(retryPath); return; }
    const marker = markerAt(editor, cursor, match);
    const before = readMarkerCursor(editor);
    if (before.text !== cursor.text || before.prefix !== cursor.prefix || before.collapsed !== cursor.collapsed) throw new Error("The editor changed during the search. Run the action again.");
    writeAttribute(editor, "AXSelectedTextMarkerRange", $.AXTextMarkerRangeCreate(null, marker, marker));
    waitForEditor(() => {
        const updated = readMarkerCursor(editor);
        if (updated.text !== cursor.text) throw new Error("The editor's text changed while moving the cursor.");
        return updated.collapsed && updated.prefix === cursor.text.slice(0, match);
    });
}
function moveUsingRange(pid) {
    const path = ObjC.unwrap($.NSProcessInfo.processInfo.environment.objectForKey("ONTEXT_MOVE_CARET_TOOL"));
    if (!path) throw new Error("This action requires an OnText version with the Move Before Text tool.");
    const task = $.NSTask.alloc.init;
    task.executableURL = $.NSURL.fileURLWithPath(path);
    task.arguments = $([String(pid)]);
    task.environment = $.NSProcessInfo.processInfo.environment;
    const output = $.NSPipe.pipe;
    task.standardError = output;
    const error = Ref();
    if (!task.launchAndReturnError(error)) {
        throw new Error(ObjC.unwrap(error[0].localizedDescription));
    }
    task.waitUntilExit;
    if (Number(task.terminationStatus) !== 0) {
        const data = output.fileHandleForReading.readDataToEndOfFile;
        const message = ObjC.unwrap($.NSString.alloc.initWithDataEncoding(data, $.NSUTF8StringEncoding));
        throw new Error(message.trim());
    }
}

function run() {
    const environment = $.NSProcessInfo.processInfo.environment;
    const searchText = ObjC.unwrap(environment.objectForKey("ONTEXT_PROMPT_1"));
    const retryPath = environment.objectForKey("ONTEXT_PROMPT_RETRY_FILE");
    if (searchText === "") { requestNewSearchText(retryPath); return; }
    const app = $.NSWorkspace.sharedWorkspace.frontmostApplication;
    const bundleID = ObjC.unwrap(app.bundleIdentifier);
    if (bundleID === "com.yeop.OnText") throw new Error("No external focused editor is available.");
    if (bundleID === "com.openai.codex") { moveUsingRange(app.processIdentifier); return; }
    const applicationElement = $.AXUIElementCreateApplication(app.processIdentifier);
    const editor = readAttribute(applicationElement, "AXFocusedUIElement");
    if (supportsTextMarkers(editor)) { moveUsingMarkers(editor, searchText, retryPath); return; }
    moveUsingRange(app.processIdentifier);
}
