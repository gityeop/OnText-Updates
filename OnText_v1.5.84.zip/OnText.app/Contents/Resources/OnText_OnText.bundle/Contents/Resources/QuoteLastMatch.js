#!/usr/bin/osascript -l JavaScript
{prompt:target}

ObjC.import("AppKit");
ObjC.import("ApplicationServices");

const quote = '"';
const smartOpeningQuote = "“";
const smartClosingQuote = "”";

function checkAX(status, operation) {
    if (status !== 0) throw new Error(operation + " failed (Accessibility error " + status + ").");
}

function readAttribute(editor, name) {
    const value = Ref();
    checkAX($.AXUIElementCopyAttributeValue(editor, $(name), value), "Read " + name);
    return ObjC.castRefToObject(value[0]);
}

function isWritable(editor, name) {
    const writable = Ref();
    const status = $.AXUIElementIsAttributeSettable(editor, $(name), writable);
    if (status === Number($.kAXErrorAttributeUnsupported)) return false;
    checkAX(status, "Check " + name);
    return Boolean(writable[0]);
}

function requireWritable(editor, name) {
    if (!isWritable(editor, name)) throw new Error("This editor does not let OnText change " + name + ".");
}

function writeAttribute(editor, name, value) {
    checkAX($.AXUIElementSetAttributeValue(editor, $(name), value), "Set " + name);
}

function waitForEditor(check, message) {
    const clock = $.NSProcessInfo.processInfo;
    const deadline = clock.systemUptime + 0.2;
    while (!check()) {
        if (clock.systemUptime >= deadline) throw new Error(typeof message === "function" ? message() : message);
        $.NSThread.sleepForTimeInterval(0.005);
    }
}

function readParameter(editor, name, parameter) {
    const value = Ref();
    checkAX($.AXUIElementCopyParameterizedAttributeValue(editor, $(name), parameter, value), "Read " + name);
    return ObjC.castRefToObject(value[0]);
}

function supportsTextMarkers(editor) {
    const available = Ref();
    const status = $.AXUIElementCopyParameterizedAttributeNames(editor, available);
    if (status === Number($.kAXErrorNotImplemented)) return false;
    checkAX(status, "Read editor accessibility capabilities");
    const names = ObjC.castRefToObject(available[0]);
    return [
        "AXTextMarkerRangeForUIElement",
        "AXStringForTextMarkerRange",
        "AXPreviousTextMarkerForTextMarker",
        "AXNextTextMarkerForTextMarker"
    ].every(name => names.containsObject(name)) && isWritable(editor, "AXSelectedTextMarkerRange");
}

function textBetween(editor, start, end) {
    const range = $.AXTextMarkerRangeCreate(null, start, end);
    return ObjC.unwrap(readParameter(editor, "AXStringForTextMarkerRange", range));
}

function readMarkerCursor(editor) {
    const editorRange = readParameter(editor, "AXTextMarkerRangeForUIElement", editor);
    const start = $.AXTextMarkerRangeCopyStartMarker(editorRange);
    const end = $.AXTextMarkerRangeCopyEndMarker(editorRange);
    const selection = readAttribute(editor, "AXSelectedTextMarkerRange");
    const caret = $.AXTextMarkerRangeCopyEndMarker(selection);
    return {
        start,
        caret,
        prefix: textBetween(editor, start, caret),
        text: textBetween(editor, start, end),
        collapsed: $.CFEqual($.AXTextMarkerRangeCopyStartMarker(selection), caret)
    };
}

// Rich text editors can span multiple accessibility nodes.
function markerAt(editor, cursor, position) {
    const backwards = cursor.prefix.length > position;
    const attribute = backwards ? "AXPreviousTextMarkerForTextMarker" : "AXNextTextMarkerForTextMarker";
    let marker = cursor.caret;
    let prefix = cursor.prefix;
    while (backwards ? prefix.length > position : prefix.length < position) {
        const next = readParameter(editor, attribute, marker);
        if ($.CFEqual(next, marker)) throw new Error("The editor could not reach the quote position.");
        marker = next;
        prefix = textBetween(editor, cursor.start, marker);
    }
    if (prefix !== cursor.text.slice(0, position)) throw new Error("Could not match the quote position in the editor.");
    return marker;
}

function snapshotPasteboard(pasteboard) {
    const snapshot = $.NSMutableArray.array;
    const items = pasteboard.pasteboardItems;
    for (let index = 0; index < items.count; index++) {
        const original = items.objectAtIndex(index);
        const copy = $.NSPasteboardItem.alloc.init;
        const types = original.types;
        for (let typeIndex = 0; typeIndex < types.count; typeIndex++) {
            const type = types.objectAtIndex(typeIndex);
            const data = original.dataForType(type);
            if (!data.isNil()) copy.setDataForType(data, type);
        }
        snapshot.addObject(copy);
    }
    return snapshot;
}

function pasteQuote(pid) {
    for (const keyDown of [true, false]) {
        const event = $.CGEventCreateKeyboardEvent(null, 9, keyDown);
        $.CGEventSetFlags(event, $.kCGEventFlagMaskCommand);
        $.CGEventPostToPid(pid, event);
    }
}

function insertQuoteAtMarker(editor, cursor, position, paste, acceptedQuotes) {
    const before = cursor.text.slice(0, position);
    const marker = markerAt(editor, cursor, position);
    writeAttribute(editor, "AXSelectedTextMarkerRange", $.AXTextMarkerRangeCreate(null, marker, marker));
    let current;
    waitForEditor(() => {
        current = readMarkerCursor(editor);
        return current.collapsed && current.prefix === before && current.text === cursor.text;
    }, () => "The editor did not confirm the quote's text marker position. " +
        "Requested offset " + position + ", reported offset " + current.prefix.length +
        ", selection collapsed " + current.collapsed + ", text matches " + (current.text === cursor.text) + ".");

    paste(acceptedQuotes[0]);
    const after = cursor.text.slice(position);
    let updated;
    waitForEditor(() => {
        updated = readMarkerCursor(editor);
        const inserted = updated.text.charAt(position);
        return acceptedQuotes.includes(inserted) &&
            updated.text === before + inserted + after && updated.collapsed && updated.prefix === before + inserted;
    }, "The editor did not confirm the quotation mark at the requested text marker.");
    return updated;
}

function quoteUsingTextMarkers(editor, pid, searchText, retryPath) {
    ObjC.import("CoreGraphics");
    ObjC.bindFunction("AXTextMarkerRangeCreate", ["id", ["id", "id", "id"]]);
    ObjC.bindFunction("AXTextMarkerRangeCopyStartMarker", ["id", ["id"]]);
    ObjC.bindFunction("AXTextMarkerRangeCopyEndMarker", ["id", ["id"]]);

    const cursor = readMarkerCursor(editor);
    if (!cursor.text.startsWith(cursor.prefix)) throw new Error("Could not locate the caret within the editor's text markers.");
    const match = lastMatch(cursor.prefix, searchText);
    if (match === null) {
        requestNewSearchText(retryPath);
        return;
    }

    const pasteboard = $.NSPasteboard.generalPasteboard;
    const snapshot = snapshotPasteboard(pasteboard);
    let changeCount = pasteboard.changeCount;
    let stagedQuote = null;
    try {
        const paste = character => {
            if (pasteboard.changeCount !== changeCount) throw new Error("The clipboard changed before the quotation mark could be pasted.");
            if (stagedQuote !== character) {
                const item = $.NSPasteboardItem.alloc.init;
                item.setStringForType(character, $.NSPasteboardTypeString);
                item.setStringForType("", "org.nspasteboard.TransientType");
                item.setStringForType("", "org.nspasteboard.AutoGeneratedType");
                changeCount = pasteboard.clearContents;
                stagedQuote = character;
                if (!pasteboard.writeObjects($([item]))) throw new Error("Could not put a quotation mark on the clipboard.");
                changeCount = pasteboard.changeCount;
            }
            pasteQuote(pid);
        };
        const opened = insertQuoteAtMarker(editor, cursor, match, paste, [quote, smartOpeningQuote]);
        const closing = opened.text.charAt(match) === smartOpeningQuote ? smartClosingQuote : quote;
        insertQuoteAtMarker(editor, opened, cursor.prefix.length + 1, paste, [closing]);
    } finally {
        if (stagedQuote !== null && pasteboard.changeCount === changeCount) {
            pasteboard.clearContents;
            if (snapshot.count > 0) pasteboard.writeObjects(snapshot);
        }
    }
}

function lastMatch(text, searchText) {
    if (searchText === "") return null;
    const options = $.NSBackwardsSearch | $.NSCaseInsensitiveSearch;
    const result = $(text).rangeOfStringOptions(searchText, options);
    return Number(result.length) === 0 ? null : Number(result.location);
}

function requestNewSearchText(path) {
    const request = JSON.stringify({
        prompt: 1,
        message: "검색 문자를 찾을 수 없습니다. 다시 입력해 주세요."
    });
    const error = Ref();
    if (!$(request).writeToFileAtomicallyEncodingError(path, true, $.NSUTF8StringEncoding, error)) {
        throw new Error(ObjC.unwrap(error[0].localizedDescription));
    }
}

function quoteUsingRange(pid) {
    const path = ObjC.unwrap($.NSProcessInfo.processInfo.environment.objectForKey("ONTEXT_MOVE_CARET_TOOL"));
    if (!path) throw new Error("This action requires an OnText version with the Move Before Text tool.");
    const task = $.NSTask.alloc.init;
    task.executableURL = $.NSURL.fileURLWithPath(path);
    task.arguments = $([String(pid), "--quote"]);
    task.environment = $.NSProcessInfo.processInfo.environment;
    const output = $.NSPipe.pipe;
    task.standardError = output;
    const error = Ref();
    if (!task.launchAndReturnError(error)) {
        throw new Error(ObjC.unwrap(error[0].localizedDescription));
    }
    task.waitUntilExit;
    if (Number(task.terminationStatus) !== 0) {
        const data = output.fileHandleForReading.readDataToEndOfFile;
        const message = ObjC.unwrap($.NSString.alloc.initWithDataEncoding(data, $.NSUTF8StringEncoding));
        throw new Error(message.trim());
    }
}

function run() {
    const environment = $.NSProcessInfo.processInfo.environment;
    const searchText = ObjC.unwrap(environment.objectForKey("ONTEXT_PROMPT_1"));
    const retryPath = environment.objectForKey("ONTEXT_PROMPT_RETRY_FILE");
    const app = $.NSWorkspace.sharedWorkspace.frontmostApplication;
    const bundleID = ObjC.unwrap(app.bundleIdentifier);
    if (bundleID === "com.yeop.OnText") {
        throw new Error("Click an editable field in the app you want to test.");
    }

    const pid = app.processIdentifier;
    const editor = readAttribute($.AXUIElementCreateApplication(pid), "AXFocusedUIElement");
    if (supportsTextMarkers(editor)) {
        quoteUsingTextMarkers(editor, pid, searchText, retryPath);
        return;
    }
    requireWritable(editor, "AXSelectedTextRange");
    requireWritable(editor, "AXSelectedText");
    quoteUsingRange(pid);
}
